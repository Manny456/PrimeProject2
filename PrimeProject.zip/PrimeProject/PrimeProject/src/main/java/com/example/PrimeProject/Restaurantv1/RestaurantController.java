package com.example.PrimeProject.Restaurantv1;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

public class RestaurantController {

    @Autowired
    private final RestaurantService restaurantService;

    public  RestaurantController(final RestaurantService restaurantService){
        this.restaurantService = restaurantService;
    }

    @RequestMapping(value = "/api/v1/restaurants", method = RequestMethod.GET)
    public List<Restaurant> findAllRestaurants(){

        return restaurantService.getAllRestaurants();
    }

    @GetMapping("/api/v1/restaurants/{id}")
    public Restaurant findSpecificRestaurant(@PathVariable("id") Long id){

        Restaurant restaurantById = this.restaurantService.getRestaurantById(id);
        return restaurantById;
    }

    @PostMapping("/api/v1/restaurants")
    public Restaurant addingNewRestaurant(@RequestBody Restaurant restaurant){
        restaurantService.createNewRestaurant(restaurant);
        return restaurant;
    }

    @PutMapping("/restaurants/{id}")
    public Restaurant editRestaurant(@PathVariable("id") Long id, @RequestBody Restaurant restaurant){
        return this.restaurantService.updateRestaurant(id, restaurant);
    }

    @DeleteMapping("/restaurants/{id}")
    public Restaurant deleteRestaurant(@PathVariable("id") Long id){
        return this.restaurantService.deleteRestaurant(id);
    }
}
